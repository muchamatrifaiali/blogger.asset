# Python program to save a 
# video using OpenCV 


import cv2
import os
import time
import datetime

video = cv2.VideoCapture(0) 

if (video.isOpened() == False): 
	print("Error reading video file") 

f = open("last.txt", "r")
last = f.read()
last = str(last)
print(last)
hapus = int(last)
hapus =hapus-3
final = int(last)
final=final+1
f = open("last.txt", "w")
f.write(str(final))
f.close()
#write last file
 

nama_file_sekarang = str(final)
nama_file_hapus = str(hapus)
if os.path.exists(nama_file_hapus+".avi"):
  os.remove(nama_file_hapus+".avi")#hapus file lama
else:
  print("The file does not exist")

a = datetime.datetime.now()#waktu

frame_width = int(video.get(3)) 
frame_height = int(video.get(4)) 
size = (frame_width, frame_height) 
result = cv2.VideoWriter(nama_file_sekarang+".avi",cv2.VideoWriter_fourcc(*'MJPG'),10, size) 
	
while(True): 
	ret, frame = video.read() 

	if ret == True: 

		# Write the frame into the 
		# file 'filename.avi' 
		result.write(frame)
		cv2.imshow('Frame', frame)
		b = datetime.datetime.now()
		c   =   b  -  a
		c = int(c.total_seconds()/60)
		if c>=3:
			a=datetime.datetime.now()
			final=final+1
			nama_file_sekarang=str(final)
			hapus=final-5
			nama_file_hapus = str(hapus)
			if os.path.exists(nama_file_hapus + ".avi"):
				os.remove(nama_file_hapus + ".avi")  # hapus file lama
			else:
				print("The file does not exist")
			result = cv2.VideoWriter(nama_file_sekarang + ".avi", cv2.VideoWriter_fourcc(*'MJPG'), 10, size)
			f = open("last.txt", "w")
			f.write(str(final))
			f.close()

		if cv2.waitKey(1) & 0xFF == ord('s'):
			break

	# Break the loop 
	else: 
		break

# When everything done, release 
# the video capture and video 
# write objects 
video.release() 
result.release() 
	
# Closes all the frames 
cv2.destroyAllWindows() 

print("The video was successfully saved") 
